package ludo.modell;

public class Flyttbart 
{
    private Rute rute;
    private Brikke brikke;
    
    public Flyttbart(Brikke brikke, Rute rute)
    {
        this.brikke = brikke;
        this.rute = rute;
    }
    
    public Rute getRute() { return rute; }
    public Brikke getBrikke() { return brikke; }
    
    public void setRute(Rute rute) { this.rute = rute; }
    public void setBrikke(Brikke brikke) { this.brikke = brikke; }
    
    public String toString()
    {
        String str;
        
        str = "\n----------**********----------\n";
        str += "Fra flyttbartobjektet:\n";
        str += "Brikke: " + brikke.toString();
        str += "Rute: " + rute.toString();
        str += "----------**********----------\n";
        
        return str;
    }
}