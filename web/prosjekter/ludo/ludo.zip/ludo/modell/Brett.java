package ludo.modell;

public class Brett implements IFarge
{
    private Rute[] rute = new Rute[92];
    private Brikke[] brikke;
    private Flyttbart[] flyttbart;
    
    public Brett(int antallSpillere)
    {             
        settOppBrett();
        
        lagBrikker(antallSpillere);    
        plasserBrikker(antallSpillere);
    }
    
    //--------------------------------------------------------------------------
    //  Brukes av finnMuligeFlytt til � bygge opp en array av lovlige flytt
    //--------------------------------------------------------------------------
    private void addFlyttbart(Brikke brikke, Rute rute)
    {
        Flyttbart[] temp = flyttbart;
        
        if(flyttbart == null)
            flyttbart = new Flyttbart[1];
        else
            flyttbart = new Flyttbart[flyttbart.length + 1];

        if(temp != null)
            for(int i=0; i < temp.length; i++)
                flyttbart[i] = temp[i];
        
        // legger til det nye objektet
        flyttbart[flyttbart.length-1] = new Flyttbart(brikke, rute);
    }
    
    //--------------------------------------------------------------------------
    //  Finner ut hvilke flytt som er mulig for denne spilleren, basert p�
    //  antall �yne terningen viser
    //--------------------------------------------------------------------------
    public Flyttbart[] finnMuligeFlytt(int tall, Spiller spiller)
    {
        flyttbart = null;
        
        for(int b=0; b < brikke.length; b++)  // for hver brikke
        {
            boolean klartSkip = true;  // denne veien l�st?
            Rute neste = null;  // brukes for � f�lge en sti
            
            if(brikke[b].getFarge() == spiller.getFarge())  // Skjekker hver brikke for riktig spiller
            {
                if(brikke[b].getRute().isM�l())
                {
                    // Denne brikken st�r i m�l, og kan ikke flyttes
                }
                else if(brikke[b].getRute().isHus())
                {
                    // Denne brikken st�r i hus, og kan ikke flyttes med mindre tall = 6
                    if(tall == 6)  // terningen viser 6
                    {
                        if(brikke[b].getRute().getNesteRute().getBlokk() != null)
                        {
                            if(brikke[b].getRute().getNesteRute().getBlokk().getFarge() != brikke[b].getFarge())
                            {
                                klartSkip = false;
                            }
                            else  // det er en blokk her, men spillerens egen
                            {
                                addFlyttbart(brikke[b], brikke[b].getRute().getNesteRute());
                            }
                        }
                        else  // ingen blokk foran hus
                        {
                            addFlyttbart(brikke[b], brikke[b].getRute().getNesteRute());
                        }  // ingen blokk foran hus
                    }  // terningen viser 6
                }
                else  // Denne brikken st�r p� en vanlig rute
                { 
                    neste = brikke[b].getRute();
                    for(int i=1; i <= tall; i++)  // for hvert �yne p� terningen
                    {
                        if(klartSkip)  // fortsatt mulig?
                        {
                            if(brikke[b].isG�ttRunde())  // g�tt runde
                            {
                                if(neste.isKryss() && neste.getFarge() == brikke[b].getFarge())  // er kryss
                                {
                                    if(i == tall)  // siste rute p� stien
                                    {
                                        addFlyttbart(brikke[b], neste.getAlternativRute());
                                    }  // siste rute p� stien
                                    else  // ikke siste rute p� siten
                                    {
                                        neste = neste.getAlternativRute();
                                    }
                                }  // er kryss
                                else  // er ikke et kryss
                                {
                                    if(i == tall)  // siste rute
                                    {
                                        if(neste.getNesteRute() != null)  // stien ledet ikke forbi m�l
                                        {
                                            if(neste.getNesteRute().getBlokk() != null)  // muligens en blokk NB!!! Her m� denne rute sjekkes ogs�!
                                            {
                                                if(neste.getNesteRute().getBlokk().getFarge() != brikke[b].getFarge())  // NB!!! Her m� denne rute sjekkes ogs�!
                                                {
                                                    klartSkip = false;
                                                }
                                                else  // det er en blokk her, men spillerens egen
                                                {
                                                    addFlyttbart(brikke[b], neste.getNesteRute());
                                                }
                                            }  // muligens en blokk
                                            else  // ingen blokk
                                            {
                                                    addFlyttbart(brikke[b], neste.getNesteRute());
                                            }  // ingen blokk
                                        }  // stien ledet ikke forbi m�l
                                        else  // stien ledet forbi m�l
                                        {
                                            klartSkip = false;
                                        }  // stien ledet forbi m�l
                                    }  // siste rute
                                    else  // ikke siste rute
                                    {
                                        if(neste.getNesteRute() == null)  // stien ledet forbi m�l
                                        {
                                            klartSkip = false;  // for f� flytt til m�l
                                        }  // stien ledet forbi m�l
                                        else  // det er en neste rute p� stien
                                        {
                                            if(neste.getNesteRute().getBlokk() != null)  // kanskje en blokk?
                                            {
                                                if(neste.getNesteRute().getBlokk().getFarge() != brikke[b].getFarge())
                                                {
                                                    klartSkip = false;  // annen spillers blokk i veien
                                                }
                                                else  // denne spillers blokk
                                                {
                                                    neste = neste.getNesteRute();
                                                }  // denne spillers blokk
                                            }  // kanskje en blokk?
                                            else  // ingen blokker
                                            {
                                                neste = neste.getNesteRute();
                                            }  // ingen blokker
                                        }  // det er en neste rute p� stien
                                    }  // ikke siste rute
                                }  // er ikke et kryss
                            }  // g�tt runde
                            else  // nettopp kommet ut av hus
                            {
                                if(i == tall)  // siste rute
                                {
                                    if(neste.getNesteRute().getBlokk() != null)  // muligens en blokk NB!!! Her m� denne rute sjekkes ogs�!
                                    {
                                        if(neste.getNesteRute().getBlokk().getFarge() != brikke[b].getFarge())  // NB!!! Her m� denne rute sjekkes ogs�!
                                        {
                                            klartSkip = false;
                                        }
                                        else  // det er en blokk her, men spillerens egen
                                        {
                                            addFlyttbart(brikke[b], neste.getNesteRute());
                                        }
                                    }  // muligens en blokk
                                    else  // ingen blokk
                                    {
                                        addFlyttbart(brikke[b], neste.getNesteRute());
                                    }  // ingen blokk
                                }  // siste rute
                                else  // del av stien
                                {
                                        if(neste.getNesteRute() == null)  // stien ledet forbi m�l
                                        {  // PS! Dette skjer egentlig aldri...
                                            klartSkip = false;  // for f� flytt til m�l
                                        }  // stien ledet forbi m�l
                                        else  // det er en neste rute p� stien
                                        {  
                                            if(neste.getNesteRute().getBlokk() != null)  // kanskje en blokk?
                                            {
                                                if(neste.getNesteRute().getBlokk().getFarge() != brikke[b].getFarge())
                                                {
                                                    klartSkip = false;  // annen spillers blokk i veien
                                                }
                                                else  // denne spillers blokk
                                                {
                                                    neste = neste.getNesteRute();
                                                }  // denne spillers blokk
                                            }  // kanskje en blokk
                                            else  // ingen blokker
                                            {
                                                neste = neste.getNesteRute();
                                            }  // ingen blokker
                                        }  // det er en neste rute p� stien
                                }  // del av stien
                            }  // nettopp kommet ut av hus
                        }  // hvis klart skip
                    }  // for hvert �yne p� terningen
                }  // vanlig rute
            }  // rett spiller
        }  // for hver brikke
        
        return flyttbart; 
    }

    //--------------------------------------------------------------------------
    //  Gj�r at datamaskinspilleren velger et flytt som er bedre enn bare
    //  et tilfeldig valgt
    //--------------------------------------------------------------------------
    public Flyttbart getBesteFlytt(Flyttbart[] f)
    {
        ludo.modell.computerspiller.CompositeBestForSpiller best = new ludo.modell.computerspiller.CompositeBestForSpiller();

        for(int i=0; i < f.length; i++)  // for hvert mulige flytt
        {
           Rute fra = f[i].getBrikke().getRute();
           Rute til = f[i].getRute();
           
           boolean lagtTil = false;
           
           // finner ut om en brikke kan sl�s inn eller blokk kan dannes
           Brikke[] brikker = til.getBrikke();
           if(brikker != null)  // det er brikker p� ruten det kan flyttes til
           {
               if(brikker[0].getFarge() != f[i].getBrikke().getFarge())  // en brikke kan sl�s inn
               {
                   best.makeStrategy(f[i], best.SL�_INN);
                   lagtTil = true;
               }  // en brikke kan sl�s inn
               else  // en blokk kan dannes
               {
                   best.makeStrategy(f[i], best.DANN_BLOKK);
                   lagtTil = true;
               }  // en blokk kan dannes
           }  // det er brikker p� ruten det kan flyttes til
           
           // finner ut om en brikke kan flyttes ut av et hus
           if(fra.isHus())
           {
               best.makeStrategy(f[i], best.FLYTT_UT);
               lagtTil = true;
           }
           
           // finner ut om en brikke kan flyttes i m�l
           if(til.isM�l())
           {
               best.makeStrategy(f[i], best.FLYTT_I_M�L);
               lagtTil = true;
           }
           
           // finner ut om en brikke vil l�se opp en blokk
           if(fra.getBrikke().length > 1)
           {
               best.makeStrategy(f[i], best.L�S_OPP_BLOKK);
               lagtTil = true;
           }
           
           // finner ut om en brikke kan flyttes i sikkerhet
           Brikke b = f[i].getBrikke();
           if(b.getFarge() == b.R�D)  // brikken er r�d
           {
               if(til.getNummer() >= 70 && til.getNummer() <= 75)  // flytter til en rute p� stien til m�l
               {
                   if(fra.getNummer() < 70 || fra.getNummer() > 75)  // flytter fra en rute som ikke er p� stien til m�l
                   {
                       best.makeStrategy(f[i], best.FLYTT_I_SIKKERHET);
                       lagtTil = true;
                   }  // flytter fra en rute som ikke er p� stien til m�l
               }  // flytter til en rute p� stien til m�l
           }  // brikken er r�d
           else if(b.getFarge() == b.GUL)  // brikken er gul
           {
               if(til.getNummer() >= 52 && til.getNummer() <= 57)  // flytter til en rute p� stien til m�l
               {
                   if(fra.getNummer() < 52 || fra.getNummer() > 57)  // flytter fra en rute som ikke er p� stien til m�l
                   {
                       best.makeStrategy(f[i], best.FLYTT_I_SIKKERHET);
                       lagtTil = true;
                   }  // flytter fra en rute som ikke er p� stien til m�l
               }  // flytter til en rute p� stien til m�l               
           }  // brikken er gul
           else if(b.getFarge() == b.GR�NN)  // brikken er gr�nn
           {
               if(til.getNummer() >= 58 && til.getNummer() <= 63)  // flytter til en rute p� stien til m�l
               {
                   if(fra.getNummer() < 58 || fra.getNummer() > 63)  // flytter fra en rute som ikke er p� stien til m�l
                   {
                       best.makeStrategy(f[i], best.FLYTT_I_SIKKERHET);
                       lagtTil = true;
                   }  // flytter fra en rute som ikke er p� stien til m�l
               }  // flytter til en rute p� stien til m�l               
           }  // brikken er gr�nn
           else if(b.getFarge() == b.BL�)  // brikken er bl�
           {
               if(til.getNummer() >= 64 && til.getNummer() <= 69)  // flytter til en rute p� stien til m�l
               {
                   if(fra.getNummer() < 64 || fra.getNummer() > 69)  // flytter fra en rute som ikke er p� stien til m�l
                   {
                       best.makeStrategy(f[i], best.FLYTT_I_SIKKERHET);
                       lagtTil = true;
                   }  // flytter fra en rute som ikke er p� stien til m�l
               }  // flytter til en rute p� stien til m�l               
           }  // brikken er bl�
           
           // hvis flyttet n� ikke er lagt til, er det et generelt flytt
           if(!lagtTil)
               best.makeStrategy(f[i], best.GENERELT_FLYTT);
        }  // for hvert mulige flytt
        
        // n� skal composite-objektet finne det beste flyttet
        return best.getBesteFlytt();
    }
    
    //--------------------------------------------------------------------------
    //  Finner ut om spilleren vant
    //--------------------------------------------------------------------------
    public boolean isVunnet(Brikke b)
    {
        if(b.getRute().isM�l())
        {
            if(b.getRute().getBrikke().length == 4)  // spilleren har vunnet!!
                return true;
        }
        
        return false;
    }
    
    //--------------------------------------------------------------------------
    // Foretar flytting av en brikke, returerer hele brettet's nye tilstand
    //--------------------------------------------------------------------------
    public Flyttbart[] flyttBrikke(Flyttbart f)
    {
        setG�ttRundeHvisG�ttRunde(f.getBrikke());  // m� muligens st� etter at brikken er flyttet!!!
        fjernBlokkHvisBlokkFjernes(f.getBrikke());
        f.getBrikke().getRute().fjernBrikke(f.getBrikke());  // fjerner brikken fra ruten den st�r p�
        f.getRute().setBrikke(f.getBrikke());  // setter brikken p� den nye ruten
        f.getBrikke().setRute(f.getRute());  // oppdaterer brikken med hvilken rute den st�r p�
        dannBlokkHvisBlokkDannes(f.getBrikke());
        sl�InnBrikkeHvisBrikkeSl�sInn(f.getBrikke());
        return getBrett();
    }
    
    //--------------------------------------------------------------------------
    //  Hvis brikken forlater eget kryss, settes g�ttRunde
    //--------------------------------------------------------------------------
    private void setG�ttRundeHvisG�ttRunde(Brikke b)
    {
        if(b.getFarge() == R�D && b.getRute().getNummer() == 42)
            b.setG�ttRunde(true);
        if(b.getFarge() == GUL && b.getRute().getNummer() == 3)
            b.setG�ttRunde(true);
        if(b.getFarge() == GR�NN && b.getRute().getNummer() == 16)
            b.setG�ttRunde(true);
        if(b.getFarge() == BL� && b.getRute().getNummer() == 29)
            b.setG�ttRunde(true);
    }
    
    //--------------------------------------------------------------------------
    //  Hvis en blokk fjernes ved dette flyttet, fjernes blokken
    //--------------------------------------------------------------------------
    private void fjernBlokkHvisBlokkFjernes(Brikke b)
    {
        if(b.getRute().getBlokk() != null)
        {
            if(b.getRute().getBrikke().length == 2)
                b.getRute().setBlokk(null);
        }
    }
    
    //--------------------------------------------------------------------------
    //  Hvis brikken st�r p� en annen med egen farge, dannes blokk
    //--------------------------------------------------------------------------
    private void dannBlokkHvisBlokkDannes(Brikke b)
    {
        Brikke[] array = b.getRute().getBrikke();
        if(array.length >= 2)
        {
            for(int i=0; i < array.length; i++)
            {
                if(i != (array.length-1))
                    if(array[i].getFarge() == array[i+1].getFarge())
                        array[i].getRute().setBlokk(new Blokk(array[i].getFarge()));
            }
        }
    }
    
    //--------------------------------------------------------------------------
    //  Sl�r inn en brikke hvis man flytter til en rute der det st�r en annen
    //--------------------------------------------------------------------------
    private void sl�InnBrikkeHvisBrikkeSl�sInn(Brikke b)
    {
        Brikke[] array = b.getRute().getBrikke();
        if(array.length >= 2)
        {
            for(int i=0; i < array.length; i++)
            {
                //if(i != (array.length-1))
                    if(array[i].getFarge() != b.getFarge())
                        sl�InnBrikke(array[i]);
            }
        }
    }
    
    //--------------------------------------------------------------------------
    //  Sl�r inn brikken
    //--------------------------------------------------------------------------
    private void sl�InnBrikke(Brikke b)
    {
        Rute r1 = b.getRute();  // ruten til brikken som skal sl�s inn
        Rute r2 = finnLedigPlassIHus(b);  // finner ledig plass i huset
        b.setRute(r2);  // sett brikke i hus
        b.setG�ttRunde(false);  // brikken begynner forfra
        r2.setBrikke(b);  // oppdater ruten i huset
        r1.fjernBrikke(b);  // oppdater ruten den stod p�
    }
    
    //--------------------------------------------------------------------------
    //  Finner en plass i huset hvor brikken kan settes
    //--------------------------------------------------------------------------
    private Rute finnLedigPlassIHus(Brikke b)
    {
        if(b.getFarge() == R�D)
        {
            for(int i=88; i <= 91; i++)
                if(rute[i].getBrikke() == null)
                    return rute[i];
        }
        else if(b.getFarge() == GUL)
        {
            for(int i=76; i <= 79; i++)
                if(rute[i].getBrikke() == null)
                    return rute[i];
        }
        else if(b.getFarge() == GR�NN)
        {
            for(int i=80; i <= 83; i++)
                if(rute[i].getBrikke() == null)
                    return rute[i];
        }
        else if(b.getFarge() == BL�)
        {
            for(int i=84; i <= 87; i++)
                if(rute[i].getBrikke() == null)
                    return rute[i];
        }
        
        return null;  // skjer aldri
    }
       
    //--------------------------------------------------------------------------
    //  Setter opp brettet
    //--------------------------------------------------------------------------
    private void settOppBrett()
    {
        for(int i=0; i < rute.length; i++)
            rute[i] = new Rute(HVIT, i);
        for(int i=rute.length-2; i >= 0; i--)
            rute[i].setNesteRute(rute[i+1]);

        // gult hus
        for(int i=76; i <= 79; i++)
        {
            rute[i].setFarge(GUL);
            rute[i].setHus(true);
            rute[i].setNesteRute(rute[3]);
        }
        // gr�nt hus
        for(int i=80; i <= 83; i++)
        {
            rute[i].setFarge(GR�NN);
            rute[i].setHus(true);
            rute[i].setNesteRute(rute[16]);            
        }
        // bl�tt hus
        for(int i=84; i <= 87; i++)
        {
            rute[i].setFarge(BL�);
            rute[i].setHus(true);
            rute[i].setNesteRute(rute[29]);            
        }
        // r�dt hus
        for(int i=88; i <= 91; i++)
        {
            rute[i].setFarge(R�D);
            rute[i].setHus(true);
            rute[i].setNesteRute(rute[42]);            
        }
        
        rute[57].setFarge(GUL);  // gult m�l
        rute[57].setM�l(true);
        rute[57].setNesteRute(null);
        rute[63].setFarge(GR�NN);  // gr�nt m�l
        rute[63].setM�l(true);
        rute[63].setNesteRute(null);
        rute[69].setFarge(BL�);  // bl�tt m�l
        rute[69].setM�l(true);
        rute[69].setNesteRute(null);
        rute[75].setFarge(R�D);  // r�dt m�l
        rute[75].setM�l(true);
        rute[75].setNesteRute(null);
        
        rute[3].setFarge(GUL);
        rute[3].setKryss(true);
        rute[3].setAlternativRute(rute[52]);  // gult kryss
        rute[3].setNesteRute(rute[4]);
        rute[16].setFarge(GR�NN);
        rute[16].setKryss(true);
        rute[16].setAlternativRute(rute[58]);  // gr�nt kryss
        rute[16].setNesteRute(rute[17]);
        rute[29].setFarge(BL�);
        rute[29].setKryss(true);
        rute[29].setAlternativRute(rute[64]);  // bl�tt kryss
        rute[29].setNesteRute(rute[30]);
        rute[42].setFarge(R�D);
        rute[42].setKryss(true);
        rute[42].setAlternativRute(rute[70]);  // r�dt kryss
        rute[42].setNesteRute(rute[43]);
        
        for(int i=52; i <= 56; i++)
            rute[i].setFarge(GUL);  // gul vei til m�l
        for(int i=58; i <= 62; i++)
            rute[i].setFarge(GR�NN);  // gr�nn vei til m�l
        for(int i=64; i <= 68; i++)
            rute[i].setFarge(BL�);  // bl� vei til m�l
        for(int i=70; i <= 74; i++)
            rute[i].setFarge(R�D);  // r�d vei til m�l
        for(int i=56; i >=52; i--)
            rute[i].setNesteRute(rute[i+1]);
        for(int i=62; i >= 58; i--)
            rute[i].setNesteRute(rute[i+1]);
        for(int i=68; i >= 64; i--)
            rute[i].setNesteRute(rute[i+1]);
        for(int i=74; i >= 70; i--)
            rute[i].setNesteRute(rute[i+1]);
                
        rute[51].setNesteRute(rute[0]);  // siste hvite
    }
    
    
    //--------------------------------------------------------------------------
    //  Lag brikker
    //--------------------------------------------------------------------------
    private void lagBrikker(int antallSpillere)
    {
        brikke = new Brikke[antallSpillere * 4];
        
        if(antallSpillere == 2)
        {
            for(int i=0; i < 4; i++)
                brikke[i] = new Brikke(R�D);
            for(int i=4; i < 8; i++)
                brikke[i] = new Brikke(GR�NN);
        }
        else if(antallSpillere == 3)
        {
            for(int i=0; i < 4; i++)
                brikke[i] = new Brikke(R�D);
            for(int i=4; i < 8; i++)
                brikke[i] = new Brikke(GUL);
            for(int i=8; i < 12; i++)
                brikke[i] = new Brikke(GR�NN);
        }
        else
        {
            for(int i=0; i < 4; i++)
                brikke[i] = new Brikke(R�D);
            for(int i=4; i < 8; i++)
                brikke[i] = new Brikke(GUL);
            for(int i=8; i < 12; i++)
                brikke[i] = new Brikke(GR�NN);
            for(int i=12; i < 16; i++)
                brikke[i] = new Brikke(BL�);
        }
    }
    
    //--------------------------------------------------------------------------
    //  Plasserer brikkene p� brettet
    //--------------------------------------------------------------------------
    private void plasserBrikker(int antallSpillere)
    {
        if(antallSpillere == 2)
        {
            for(int i=0; i < 4; i++)
            {
                brikke[i].setRute(rute[88+i]);  // r�de brikker
                brikke[i+4].setRute(rute[80+i]);  // gr�nne brikker
            }
        }
        else if(antallSpillere == 3)
        {
            for(int i=0; i < 4; i++)
            {
                brikke[i].setRute(rute[88+i]);  // r�de brikker
                brikke[i+4].setRute(rute[76+i]);  // gule brikker
                brikke[i+8].setRute(rute[80+i]);  // gr�nne brikker
            }
        }
        else if(antallSpillere == 4)
        {
            for(int i=0; i < 4; i++)
            {
                brikke[i].setRute(rute[88+i]);  // r�de brikker
                brikke[i+4].setRute(rute[76+i]);  // gule brikker
                brikke[i+8].setRute(rute[80+i]);  // gr�nne brikker
                brikke[i+12].setRute(rute[84+i]);  // bl� brikker
            }            
        }
                
        // Oppdaterer rutene
        for(int i=0; i < brikke.length; i++)
            brikke[i].getRute().setBrikke(brikke[i]);
    }
        
    //--------------------------------------------------------------------------
    //  Lager en array av flytbartobjekter, som har alle brikker i spillet
    //--------------------------------------------------------------------------
    public Flyttbart[] getBrett()
    {
        Flyttbart[] oppsett = new Flyttbart[brikke.length];
        //System.out.println("Antall brikker i modellen: " + brikke.length);
        for(int i=0; i < brikke.length; i++)
        {
            /*System.out.println("----------**********----------");
            System.out.print(brikke[i]);*/
            oppsett[i] = new Flyttbart(brikke[i], brikke[i].getRute());
        }
        
        return oppsett;
    }
}