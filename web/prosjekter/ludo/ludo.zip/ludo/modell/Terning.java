package ludo.modell;

public class Terning
{
    private int tall;
    
    public Terning()
    {
        trill();
    }
    
    public int getTall() { return tall; }
    
    public int trill()
    {
        tall = (int)(Math.random() * 6);  // 0-5
        tall++;  // 1-6
        
        return tall;
    }
}