package ludo.modell.computerspiller;

public class L�sOppBlokkStrategy implements IFlyttStrategy
{
    private ludo.modell.Flyttbart flyttbart;
    
    public L�sOppBlokkStrategy(ludo.modell.Flyttbart f)
    {
        flyttbart = f;
    }
    
    public ludo.modell.Flyttbart getFlyttbart() 
    {
        return flyttbart;
    } 
}