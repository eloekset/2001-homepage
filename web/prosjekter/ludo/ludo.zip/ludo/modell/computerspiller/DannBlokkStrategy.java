package ludo.modell.computerspiller;

public class DannBlokkStrategy implements IFlyttStrategy
{
    private ludo.modell.Flyttbart flyttbart;
    
    public DannBlokkStrategy(ludo.modell.Flyttbart f)
    {
        flyttbart = f;
    }
    
    public ludo.modell.Flyttbart getFlyttbart() 
    {
        return flyttbart;
    }
}