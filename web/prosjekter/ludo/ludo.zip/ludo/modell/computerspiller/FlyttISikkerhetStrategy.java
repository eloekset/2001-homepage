package ludo.modell.computerspiller;

public class FlyttISikkerhetStrategy implements IFlyttStrategy
{
    private ludo.modell.Flyttbart flyttbart;
    
    public FlyttISikkerhetStrategy(ludo.modell.Flyttbart f)
    {
        flyttbart = f;
    }
    
    public ludo.modell.Flyttbart getFlyttbart() 
    {
        return flyttbart;
    }
}