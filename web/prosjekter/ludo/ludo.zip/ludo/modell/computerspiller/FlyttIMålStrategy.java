package ludo.modell.computerspiller;

public class FlyttIM�lStrategy implements IFlyttStrategy
{
    private ludo.modell.Flyttbart flyttbart;
    
    public FlyttIM�lStrategy(ludo.modell.Flyttbart f)
    {
        flyttbart = f;
    }
    
    public ludo.modell.Flyttbart getFlyttbart() 
    {
        return flyttbart;
    }
}