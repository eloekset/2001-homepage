package ludo.modell.computerspiller;

public class GenereltFlyttStrategy implements IFlyttStrategy
{
    private ludo.modell.Flyttbart flyttbart;
    
    public GenereltFlyttStrategy(ludo.modell.Flyttbart f)
    {
        flyttbart = f;
    }
    
    public ludo.modell.Flyttbart getFlyttbart() 
    {
        return flyttbart;
    }
}