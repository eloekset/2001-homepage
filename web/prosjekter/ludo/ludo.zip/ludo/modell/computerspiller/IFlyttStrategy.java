
package ludo.modell.computerspiller;

public interface IFlyttStrategy 
{    
    public ludo.modell.Flyttbart getFlyttbart();
}