package ludo.modell.computerspiller;

public class FlyttUtAvHusStrategy implements IFlyttStrategy
{
    private ludo.modell.Flyttbart flyttbart;
    
    public FlyttUtAvHusStrategy(ludo.modell.Flyttbart f)
    {
        flyttbart = f;
    }
    
    public ludo.modell.Flyttbart getFlyttbart() 
    {
        return flyttbart;
    }
}