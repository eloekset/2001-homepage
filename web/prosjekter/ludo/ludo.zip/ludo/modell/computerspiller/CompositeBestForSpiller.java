package ludo.modell.computerspiller;

public class CompositeBestForSpiller
{
    public final int SL�_INN = 0;
    public final int FLYTT_UT = 1;
    public final int DANN_BLOKK = 2;
    public final int FLYTT_I_SIKKERHET = 3;
    public final int FLYTT_I_M�L = 4;
    public final int GENERELT_FLYTT = 5;
    public final int L�S_OPP_BLOKK = 6;
    
    IFlyttStrategy[] flytt;
    
    public CompositeBestForSpiller()
    {
        flytt = null;
    }
    
    //--------------------------------------------------------------------------
    //  Brukes av makeStrategy til � legge en ny strategi til arrayen
    //--------------------------------------------------------------------------
    private void addFlytt(IFlyttStrategy f)
    {
        IFlyttStrategy[] temp = flytt;
        
        if(flytt == null)
            flytt = new IFlyttStrategy[1];
        else
            flytt = new IFlyttStrategy[flytt.length+1];
        
        if(temp != null)
            for(int i=0; i < temp.length; i++)
                flytt[i] = temp[i];
        
        flytt[flytt.length-1] = f;
    }
    
    //--------------------------------------------------------------------------
    //  Lager en ny strategi av den rette typen
    //--------------------------------------------------------------------------
    public void makeStrategy(ludo.modell.Flyttbart f, int typeStrategy)
    {
        if(typeStrategy == SL�_INN)
            addFlytt(new Sl�InnStrategy(f));
        else if(typeStrategy == FLYTT_UT)
            addFlytt(new FlyttUtAvHusStrategy(f));
        else if(typeStrategy == DANN_BLOKK)
            addFlytt(new DannBlokkStrategy(f));
        else if(typeStrategy == FLYTT_I_SIKKERHET)
            addFlytt(new FlyttISikkerhetStrategy(f));
        else if(typeStrategy == FLYTT_I_M�L)
            addFlytt(new FlyttIM�lStrategy(f));
        else if(typeStrategy == GENERELT_FLYTT)
            addFlytt(new GenereltFlyttStrategy(f));
        else if(typeStrategy == L�S_OPP_BLOKK)
            addFlytt(new L�sOppBlokkStrategy(f));        
    }
    
    //--------------------------------------------------------------------------
    //  Velger ut det beste flyttet etter hvilken strategi som er antatt best
    //--------------------------------------------------------------------------
    public ludo.modell.Flyttbart getBesteFlytt()
    {
        IFlyttStrategy beste = null;
        
        if(flytt == null)
            return null;
        else
        {
            for(int i=0; i < flytt.length; i++)  // for hvert flytt, velg det beste
            {
                if(flytt[i] instanceof Sl�InnStrategy)  // det beste flyttet
                {
                    beste = flytt[i];
                }
                else if(flytt[i] instanceof FlyttUtAvHusStrategy)  // det neste beste flyttet osv...
                {
                    if(beste instanceof Sl�InnStrategy) { }
                    else                        
                        beste = flytt[i];
                }
                else if(flytt[i] instanceof DannBlokkStrategy)
                {
                    if(beste instanceof Sl�InnStrategy) { }
                    else if(beste instanceof FlyttUtAvHusStrategy) { }
                    else
                        beste = flytt[i];
                }
                else if(flytt[i] instanceof FlyttISikkerhetStrategy)
                {
                    if(beste instanceof Sl�InnStrategy) { }
                    else if(beste instanceof FlyttUtAvHusStrategy) { }
                    else if(beste instanceof DannBlokkStrategy) { }
                    else
                        beste = flytt[i];
                }
                else if(flytt[i] instanceof FlyttIM�lStrategy)
                {
                    if(beste instanceof Sl�InnStrategy) { }
                    else if(beste instanceof FlyttUtAvHusStrategy) { }
                    else if(beste instanceof DannBlokkStrategy) { }
                    else if(beste instanceof FlyttISikkerhetStrategy) { }
                    else
                        beste = flytt[i];
                }
                else if(flytt[i] instanceof GenereltFlyttStrategy)
                {
                    if(beste instanceof Sl�InnStrategy) { }
                    else if(beste instanceof FlyttUtAvHusStrategy) { }
                    else if(beste instanceof DannBlokkStrategy) { }
                    else if(beste instanceof FlyttISikkerhetStrategy) { }
                    else if(beste instanceof FlyttIM�lStrategy) { }
                    else
                        beste = flytt[i];
                }
                else if(flytt[i] instanceof L�sOppBlokkStrategy)  // det d�rligste flyttet
                {
                    if(beste instanceof Sl�InnStrategy) { }
                    else if(beste instanceof FlyttUtAvHusStrategy) { }
                    else if(beste instanceof DannBlokkStrategy) { }
                    else if(beste instanceof FlyttISikkerhetStrategy) { }
                    else if(beste instanceof FlyttIM�lStrategy) { }
                    else if(beste instanceof GenereltFlyttStrategy) { }
                    else
                        beste = flytt[i];
                }
            }  // for hvert flytt, velg det beste
        }
        
        if(beste == null)
            return null;
        else
            return beste.getFlyttbart();
    }
}