package ludo.modell.computerspiller;

public class Sl�InnStrategy implements IFlyttStrategy
{
    private ludo.modell.Flyttbart flyttbart;
    
    public Sl�InnStrategy(ludo.modell.Flyttbart f)
    {
        flyttbart = f;
    }
    
    public ludo.modell.Flyttbart getFlyttbart() 
    {
        return flyttbart;
    }
}