package ludo.modell;

public class Respons
{
    public final int TRILL_TERNING = 0;
    public final int FLYTT_BRIKKE = 1;
    
    private int terningVerdi;
    private Flyttbart[] flyttbart;
    private Spiller spillersTur;
    private Spiller vunnet;
    private int nesteHandling;
    
    public int getTerningVerdi() { return terningVerdi; }
    public Flyttbart[] getFlyttbart() { return flyttbart; }
    public Spiller getSpillersTur() { return spillersTur; }
    public Spiller getVunnet() { return vunnet; }
    public int getNesteHandling() { return nesteHandling; }
    
    public void setTerningVerdi(int t) { terningVerdi = t; }
    public void setFlyttbart(Flyttbart[] f) { flyttbart = f; }
    public void setSpillersTur(Spiller spiller) { spillersTur = spiller; }
    public void setVunnet(Spiller spiller) { vunnet = spiller; }
    public void setNesteHandling(int handling) { nesteHandling = handling; }
}