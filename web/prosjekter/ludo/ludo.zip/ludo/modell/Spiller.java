package ludo.modell;

public class Spiller implements IFarge
{
    public static final int HUMAN = 0;
    public static final int COMPUTER = 1;
    
    private String navn;
    private int type;
    private int farge;
    private boolean vunnet;
    private int flyttIgjen;
    
    public Spiller(String navn, int type, int farge)
    {
        this.navn = navn;
        this.type = type;
        this.farge = farge;
        vunnet = false;
        flyttIgjen = 59;
    }
    
    public String getNavn() { return navn; }
    public int getType() { return type; }
    public int getFarge() { return farge; }
    public boolean isVunnet() { return vunnet; }
    public int getFlyttIgjen() { return flyttIgjen; }
    
    public void setVunnet(boolean b) { vunnet = b; }
}