package ludo.modell;

public class Rute implements IFarge
{
    private int farge = 0;
    private int nummer = 0;
    private boolean kryss;  // ruten utenfor huset
    private boolean hus;
    private boolean m�l;
    private Brikke[] brikke;
    private Rute nesteRute;
    private Rute alternativRute;
    private Blokk blokk;    
    
    public Rute(int farge, int nummer)
    {
        this.farge = farge;
        this.nummer = nummer;
        kryss = false;
        hus = false;
        m�l = false;
    }    
    
    public int getFarge() { return farge; }
    public int getNummer() { return nummer; }
    public boolean isKryss() { return kryss; }    
    public boolean isHus() { return hus; }
    public boolean isM�l() { return m�l; }
    public Brikke[] getBrikke() { return brikke; }
    public Blokk getBlokk() { return blokk; }
    public Rute getNesteRute() { return nesteRute; }
    public Rute getAlternativRute() { return alternativRute; }
    
    public void setFarge(int farge) { this.farge = farge; }
    public void setNummer(int nummer) { this.nummer = nummer; }
    public void setKryss(boolean b) { kryss = b; }
    public void setHus(boolean b) { hus = b; }
    public void setM�l(boolean b) { m�l = b; }
    public void setBrikke(Brikke b) { addBrikke(b); }
    public void setBlokk(Blokk blokk) { this.blokk = blokk; }
    public void setNesteRute(Rute rute) { nesteRute = rute; }
    public void setAlternativRute(Rute rute) { alternativRute = rute; }
    
    private void addBrikke(Brikke b)
    {
        if(brikke == null)
            brikke = new Brikke[0];
        
        Brikke[] temp = brikke;
        brikke = new Brikke[brikke.length+1];
        
        for(int i=0; i < temp.length; i++)
            brikke[i] = temp[i];
        
        brikke[brikke.length-1] = b;
    }
    
    public void fjernBrikke(Brikke b)
    {
        if(brikke == null)  // ingen brikker
            return;
        else if(brikke.length == 1)  // �n brikke
        {
            brikke = null;
        }
        else  // mer enn �n brikke
        {
            Brikke[] temp = brikke;
            
            // fjern den aktuelle brikken
            for(int i=0; i < brikke.length; i++)
            {
                if(temp[i] == b)
                    temp[i] = null;
            }
            
            // lag en ny array med �n brikke mindre
            brikke = new Brikke[temp.length-1];
            int nr = 0;
            
            // ta vare p� de resterende brikkene
            for(int i=0; i < temp.length; i++)
            {
                if(temp[i] != null)
                    brikke[nr++] = temp[i];
            }
        }
    }
    
    public void t�mBrikkeArray()
    {
        brikke = null;
    }
    
    public String toString()
    {
        String farge;
        String kryss;
        String hus;
        String m�l;
        String brikke;
        String nesteRute;
        String alternativRute;
        String blokk;
        String str;
        
        if(this.farge == R�D)
            farge = "r�d";
        else if(this.farge == GUL)
            farge = "gul";
        else if(this.farge == GR�NN)
            farge = "gr�nn";
        else if(this.farge == BL�)
            farge = "bl�";
        else if(this.farge == HVIT)
            farge = "hvit";
        else
            farge = "ukjent(!)";
        
        if(this.kryss)
            kryss = "ja";
        else
            kryss = "nei";
        
        if(this.hus)
            hus = "ja";
        else
            hus = "nei";
        
        if(this.m�l)
            m�l = "ja";
        else
            m�l = "nei";
        
        if(this.brikke == null)
            brikke = "0";
        else
            brikke = "" + this.brikke.length;
        
        if(this.nesteRute == null)
            nesteRute = "ingen";
        else
            nesteRute = "" + this.nesteRute.getNummer();
        
        if(this.alternativRute == null)
            alternativRute = "ingen";
        else
            alternativRute = "" + this.alternativRute.getNummer();
        
        if(this.blokk == null)
            blokk = "ingen";
        else
            blokk = "" + this.blokk.getFarge();
        
        str = "Rute nummer: " + nummer + ", farge: " + farge + ", ";
        str += "kryss: " + kryss + ", m�l: " + m�l + ", hus: " + hus + ", ";
        str += "brikker: " + brikke + ", neste rute: " + nesteRute + ", ";
        str += "alternativ rute: " + alternativRute + ", ";
        str += "blokk: " + blokk + ".\n";
        return str;
    }
}
