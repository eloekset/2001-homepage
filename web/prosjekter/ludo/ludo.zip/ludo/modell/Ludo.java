package ludo.modell;

public class Ludo implements IFarge
{
    private int antSpillere;
    private int spillersTur;
    private boolean sisteKastVarSeks = false;
    private Spiller[] spiller;
    private Terning terning;
    private Brett brett;
    private Respons sisteRespons = new Respons();
        
    public Ludo(String[] navn, int[] type) 
    {
        sisteRespons.setNesteHandling(sisteRespons.TRILL_TERNING);
        
        this.antSpillere = navn.length;
        spiller = new Spiller[antSpillere];
        spillersTur = R�D;
        
        if(antSpillere == 2)
        {
            spiller[0] = new Spiller(navn[0], type[0], R�D);
            spiller[1] = new Spiller(navn[1], type[1], GR�NN);
        }
        else if(antSpillere == 3)
        {
            spiller[0] = new Spiller(navn[0], type[0], R�D);
            spiller[1] = new Spiller(navn[1], type[1], GUL);            
            spiller[2] = new Spiller(navn[2], type[2], GR�NN);
        }
        else if(antSpillere == 4)
        {
            spiller[0] = new Spiller(navn[0], type[0], R�D);
            spiller[1] = new Spiller(navn[1], type[1], GUL);            
            spiller[2] = new Spiller(navn[2], type[2], GR�NN);
            spiller[3] = new Spiller(navn[3], type[3], BL�);
        }
        
        terning = new Terning();
        brett = new Brett(antSpillere);
    }
    
    public Respons trillTerning()
    {
        if(sisteRespons != null)
        {
            if(sisteRespons.getNesteHandling() == sisteRespons.TRILL_TERNING)
            {
                Respons respons = new Respons();

                respons.setTerningVerdi(terning.trill());  // triller terning
                if(respons.getTerningVerdi() != 6)
                    sisteKastVarSeks = false;
                else
                    sisteKastVarSeks = true;

                respons.setFlyttbart(brett.finnMuligeFlytt(terning.getTall(), spiller[spillersTur-1]));  // finner mulige flytt
                if(respons.getFlyttbart() == null)
                {
                    // ingen mulige flytt!

                    // finn neste spillers tur
                    finnNesteSpillersTur();

                    respons.setSpillersTur(spiller[spillersTur-1]);
                    respons.setNesteHandling(respons.TRILL_TERNING);
                }
                else
                {
                    // flytt var mulig
                    respons.setSpillersTur(spiller[spillersTur-1]);
                    respons.setNesteHandling(respons.FLYTT_BRIKKE);
                }

                sisteRespons = respons;
                return respons;
            }
        }
        
        return null;
    }
    
    public Respons flyttBrikke(Flyttbart f)
    {
        if(sisteRespons != null)
        {
            if(sisteRespons.getNesteHandling() == sisteRespons.FLYTT_BRIKKE)
            {
                Respons respons = new Respons();
                Flyttbart[] flyttbart = brett.flyttBrikke(f);

                // lagrer posisjonen til brikkene som ble flyttet
                respons.setFlyttbart(flyttbart);

                if(brett.isVunnet(f.getBrikke()))
                {
                    spiller[spillersTur-1].setVunnet(true);
                    respons.setVunnet(spiller[spillersTur-1]);
                }

                // finner ut hvem det er sin tur
                finnNesteSpillersTur();

                respons.setSpillersTur(spiller[spillersTur-1]);
                respons.setNesteHandling(respons.TRILL_TERNING);

                sisteRespons = respons;
                return respons;
            }
        }
        
        return null;
    }
    
    
    //--------------------------------------------------------------------------
    //  Ber brett finne ut hva som er det beste av f�lgende flytt.
    //  Brukes av COMPUTER-spillere.
    //--------------------------------------------------------------------------
    public Flyttbart getBesteFlytt(Flyttbart[] f)
    {
        return brett.getBesteFlytt(f);
    }
    
    public Flyttbart[] getBrett()
    {
        return brett.getBrett();
    }
    
    public Spiller[] getSpillere()
    {
        return spiller;
    }
    
    public Spiller getSpiller(int i)
    {
        return spiller[i];
    }
    
    public boolean isAlleVunnet()
    {
        boolean alleVunnet = true;
        
        for(int i=0; i < spiller.length; i++)
            if(!spiller[i].isVunnet())
                alleVunnet = false;
            
        return alleVunnet;
    }
    
    //--------------------------------------------------------------------------
    // Finner ut hvem det er sin tur
    //--------------------------------------------------------------------------
    private void finnNesteSpillersTur()
    {
        if(!sisteKastVarSeks)
        {
            boolean b = true;
            int i = 0;
            while(b)
            {
                spillersTur++;
                if(spillersTur > antSpillere)
                    spillersTur = R�D;
                
                if(!spiller[spillersTur-1].isVunnet())
                    b = false;  // det er denne spillers tur
                
                i++;
                if(i >= 4)  // alle spillerne har kommet i m�l
                    b = false;  // ingen spillere kan fortsette
            }
        }
    }
}