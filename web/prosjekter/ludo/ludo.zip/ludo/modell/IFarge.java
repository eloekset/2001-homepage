package ludo.modell;

public interface IFarge {

    static final int HVIT = 0;
    
    static final int R�D = 1;
    
    static final int GUL = 2;
    
    static final int GR�NN = 3;
    
    static final int BL� = 4;
}

