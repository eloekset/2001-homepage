package ludo.modell;

public class Brikke implements IFarge
{
    private int farge;
    private boolean g�ttRunde;
    private Rute rute;
    
    public Brikke(int farge)
    {
        this.farge = farge;
        g�ttRunde = false;
    }
    
    public int getFarge() { return farge; }
    public boolean isG�ttRunde() { return g�ttRunde; }
    public Rute getRute() { return rute; }
    
    public void setG�ttRunde(boolean b) { g�ttRunde = b; }
    public void setRute(Rute rute) 
    { 
        this.rute = rute; 
        //System.out.println("Brikke plassert p� rute nr. " + rute.getNummer() + ".");
    }
    
    public String toString()
    {
        String farge;
        String str;
        
        if(this.farge == R�D)
            farge = "r�d";
        else if(this.farge == GUL)
            farge = "gul";
        else if(this.farge == GR�NN)
            farge = "gr�nn";
        else if(this.farge == BL�)
            farge = "bl�";
        else
            farge = "ukjent(!)";
        
        str = "Denne brikken har farge " + farge + ", og st�r p� rute nummer ";
        str += "" + rute.getNummer() + ".\n";
        return str;
    }
}
