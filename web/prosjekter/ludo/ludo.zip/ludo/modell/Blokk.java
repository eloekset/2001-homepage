package ludo.modell;

public class Blokk implements IFarge
{
    private int farge;
    
    public Blokk(int farge)
    {
        this.farge = farge;
    }
    
    public int getFarge() { return farge; }
}