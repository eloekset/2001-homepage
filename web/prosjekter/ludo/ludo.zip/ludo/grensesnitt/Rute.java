package ludo.grensesnitt;

import java.awt.*;
import javax.swing.*;

public class Rute
{
    private int posX;
    private int posY;
    private int width;
    private int height;
    private int nr;
    private Color merketFraFarge = new Color(0, 0, 0, 128);
    private Color merketTilFarge = new Color(226, 0, 112, 128);
    
    public Rute(int nr, int x, int y, int w, int h)
    {
        posX = x;
        posY = y;
        width = w;
        height = h;
        this.nr = nr;
    }
    
    public void tegnMerketFra(JLabel brett)
    {
        Graphics g = brett.getGraphics();
        Color old = null;
        if(g.getColor() != null)
            old = g.getColor();
        g.setColor(merketFraFarge);
        g.fillRect(posX, posY, width, height);
        g.setColor(old);
    }

    public void tegnMerketTil(JLabel brett)
    {
        Graphics g = brett.getGraphics();
        Color old = null;
        if(g.getColor() != null)
            old = g.getColor();
        g.setColor(merketTilFarge);
        g.fillRect(posX, posY, width, height);
        g.setColor(old);
    }
    
    public int getX() { return posX; }
    public int getY() { return posY; }
    public int getWidth() { return width; }
    public int getHeight() { return height; }
    public int getNr() { return nr; }
    
    public String toString()
    {
        String str;
        
        str = "Rute nr: " + nr + ", x: " + posX + ", ";
        str += "y: " + posY + ", w: " + width + ", h: " + height + ".";
        return str;
    }
}