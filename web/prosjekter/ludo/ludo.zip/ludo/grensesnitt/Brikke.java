package ludo.grensesnitt;

import java.awt.*;
import javax.swing.*;

public class Brikke extends ImageIcon
{
    private int posX;
    private int posY;
    private ImageIcon icon;
    
    public Brikke(int x, int y, ImageIcon i)
    {
        posX = x;
        posY = y;
        icon = i;
    }
    
    public void paint(JLabel brett, String tall)
    {
        brett.getGraphics().drawImage(icon.getImage(), posX+1, posY+1, brett);
        //brett.getGraphics().setColor(new Color(0, 180, 180, 255));
        brett.getGraphics().drawString(tall, posX+7, posY+13);
    }
    
    public int getX() { return posX; }
    public int getY() { return posY; }
    
    public void setX(int x) { posX = x; }
    public void setY(int y) { posY = y; }
    
    public String toString()
    {
        return "Denne brikken st�r p� x=" + posX + " y=" + posY + ".";        
    }
}