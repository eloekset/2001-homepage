package ludo.grensesnitt;

import java.awt.*;
import javax.swing.*;

public class Brett
{
    // instillinger for brettet
    private final int RUTE_WIDTH = 20;
    private final int RUTE_HEIGHT = 20;
    private final int RUTE1_X = 120;
    private final int RUTE1_Y = 0;
    private final int MELLOM_RUTER_I_HUS = 14;
    private final int HUSKANT_YTRE = 21;
    private final int HUSKANT_INDRE = 13;
    private final int HUSKANT = HUSKANT_YTRE + HUSKANT_INDRE;
    
    private int[] tegnetFra;
    private int[] tegnetTil;
    private Rute[] rute = new Rute[92];
    private Brikke[] brikke;
    private ImageIcon gulBrikke = new ImageIcon(getClass().getResource("/ludo/grensesnitt/grafikk/gul_1.gif"));
    private ImageIcon gr�nnBrikke = new ImageIcon(getClass().getResource("/ludo/grensesnitt/grafikk/gr�nn_1.gif"));
    private ImageIcon bl�Brikke = new ImageIcon(getClass().getResource("/ludo/grensesnitt/grafikk/bl�_1.gif"));
    private ImageIcon r�dBrikke = new ImageIcon(getClass().getResource("/ludo/grensesnitt/grafikk/r�d_1.gif"));
    private JLabel ludoBrettet;
    
    public Brett(ludo.modell.Flyttbart[] oppsett, JLabel jl)
    {
        ludoBrettet = jl;  // trenger graphics context til dette
        settOppRuter();  // setter opp ruter
        
        /*for(int i=0; i < rute.length; i++)
            System.out.println(rute[i]);*/
        
        // setter opp brikker
        brikke = new Brikke[oppsett.length];
        //System.out.println("" + oppsett.length);
        
        for(int i=0; i < oppsett.length; i++)
        {
            ludo.modell.Brikke enBrikke = oppsett[i].getBrikke();
            int nr = oppsett[i].getRute().getNummer();            
            
            if(enBrikke.getFarge() == enBrikke.R�D)
                brikke[i] = new Brikke(rute[nr].getX(), rute[nr].getY(), r�dBrikke);
            else if(enBrikke.getFarge() == enBrikke.GUL)
                brikke[i] = new Brikke(rute[nr].getX(), rute[nr].getY(), gulBrikke);
            else if(enBrikke.getFarge() == enBrikke.GR�NN)
                brikke[i] = new Brikke(rute[nr].getX(), rute[nr].getY(), gr�nnBrikke);
            else
                brikke[i] = new Brikke(rute[nr].getX(), rute[nr].getY(), bl�Brikke);
            
            //System.out.println(brikke[i]);
        }
    }
    
    public void paint()
    {
        for(int i=0; i < brikke.length; i++)
        {
            int tall = 0;
            
            for(int j=0; j < brikke.length; j++)
            {
                if(brikke[j].getX() == brikke[i].getX() && brikke[j].getY() == brikke[i].getY())
                    tall++;
            }

            if(tall > 1)
                brikke[i].paint(ludoBrettet, "" + tall);
            else
                brikke[i].paint(ludoBrettet, "");
        }
    }
    
    public void tegnLovligeFlytt(ludo.modell.Flyttbart[] flyttbart)
    {
        int ruteNummer;
        tegnetFra = new int[0];
        tegnetTil = new int[0];
        boolean alleredeTegnet = false;
                
        for(int i=0; i < flyttbart.length; i++)
        {
            // rutenummeret til brikken som kan flyttes
            ruteNummer = flyttbart[i].getBrikke().getRute().getNummer();
            
            alleredeTegnet = false;
            for(int j=0; j < tegnetFra.length; j++)
                if(tegnetFra[j] == ruteNummer)
                    alleredeTegnet = true;
            
            if(!alleredeTegnet)
            {
                rute[ruteNummer].tegnMerketFra(ludoBrettet);  // OBS! M� flyttes
                addTegnetFra(ruteNummer);
                //System.out.println("Har tegnet brikke i rute " + ruteNummer + " som lovlig flytt.");
            }
            
            
            // rutenummeret til ruten brikken kan flyttes til
            ruteNummer = flyttbart[i].getRute().getNummer();

            alleredeTegnet = false;
            for(int j=0; j < tegnetTil.length; j++)
                if(tegnetTil[j] == ruteNummer)
                    alleredeTegnet = true;

            if(!alleredeTegnet)
            {
                rute[ruteNummer].tegnMerketTil(ludoBrettet);  // OBS! M� flyttes
                addTegnetTil(ruteNummer);
                //System.out.println("Har tegnet rute " + ruteNummer + " som lovlig flytt.");
            }
        }
    }
    
    public int finnRuteP�Posisjon(Point punkt)
    {
        Point p = new Point((int)punkt.getX(), (int)punkt.getY());
        
        for(int i=0; i < rute.length; i++)
        {
            if(rute[i].getX() <= p.getX() && (rute[i].getX() + rute[i].getWidth()) >= p.getX())
            {
                if(rute[i].getY() <= p.getY() && (rute[i].getY() + rute[i].getHeight()) >= p.getY())
                {
                    return i;
                }
            }
        }
        
        // klikket utenom en rute
        return -1;
    }
    
    public void visEndring(ludo.modell.Flyttbart[] oppdatering)
    {
        for(int i=0; i < oppdatering.length; i++)
        {
            int nr = oppdatering[i].getBrikke().getRute().getNummer();
            
            brikke[i].setX(rute[nr].getX());
            brikke[i].setY(rute[nr].getY());
        }
    }
    
    //--------------------------------------------------------------------------
    // Flytter en brikke til angitt rute
    //--------------------------------------------------------------------------
    private void flyttBrikke(Brikke brikke, Rute rute)
    {
/*        if(brikke == null)
            System.out.println("Flyttbartobjektet hadde ingen brikke!");
        if(rute == null)
            System.out.println("Flyttbartobjektet hadde ingen rute!");*/
        
        brikke.setX(rute.getX());
        brikke.setY(rute.getY());
    }
    
    private void addTegnetFra(int nr)
    {
        int[] temp = tegnetFra;
        
        tegnetFra = new int[tegnetFra.length + 1];
        
        for(int i=0; i < temp.length; i++)
            tegnetFra[i] = temp[i];
        
        tegnetFra[tegnetFra.length - 1] = nr;
    }
    
    private void addTegnetTil(int nr)
    {
        int[] temp = tegnetTil;
        
        tegnetTil = new int[tegnetTil.length + 1];
        
        for(int i=0; i < temp.length; i++)
            tegnetTil[i] = temp[i];
        
        tegnetTil[tegnetTil.length - 1] = nr;
    }
    
    //--------------------------------------------------------------------------
    //  Lager ruteobjekter som passer til brettet
    //--------------------------------------------------------------------------
    private void settOppRuter()
    {
        for(int i=0; i < 3; i++)
            rute[i] = new Rute(i, RUTE1_X + i*RUTE_WIDTH, RUTE1_Y, RUTE_WIDTH, RUTE_HEIGHT);
        // rekke til venstre for gult hus
        for(int i=3; i < 8; i++)
            rute[i] = new Rute(i, rute[i-1].getX(), rute[i-1].getY() + RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        // rekke under gult hus
        rute[8] = new Rute(8, rute[7].getX() + RUTE_WIDTH, rute[7].getY() + RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        for(int i=9; i < 14; i++)
            rute[i] = new Rute(i, rute[i-1].getX() + RUTE_WIDTH, rute[i-1].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        // rute 15 og 16
        rute[14] = new Rute(14, rute[13].getX(), rute[13].getY() + RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        rute[15] = new Rute(15, rute[14].getX(), rute[14].getY() + RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        // rekke over gr�nt hus
        for(int i=16; i < 21; i++)
            rute[i] = new Rute(i, rute[i-1].getX() - RUTE_WIDTH, rute[i-1].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        // rekke til venstre for gr�nt hus
        rute[21] = new Rute(21, rute[20].getX() - RUTE_WIDTH, rute[20].getY() + RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        for(int i=22; i < 27; i++)
            rute[i] = new Rute(i, rute[i-1].getX(), rute[i-1].getY() + RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        // rute 28 og 29
        rute[27] = new Rute(27, rute[26].getX() - RUTE_WIDTH, rute[26].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        rute[28] = new Rute(28, rute[27].getX() - RUTE_WIDTH, rute[27].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        // rekke til h�yre for bl�tt hus
        for(int i=29; i < 34; i++)
            rute[i] = new Rute(i, rute[i-1].getX(), rute[i-1].getY() - RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        // rekke over bl�tt hus
        rute[34] = new Rute(34, rute[33].getX() - RUTE_WIDTH, rute[33].getY() - RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        for(int i=35; i < 40; i++)
            rute[i] = new Rute(i, rute[i-1].getX() - RUTE_WIDTH, rute[i-1].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        // rute 41 og 42
        rute[40] = new Rute(40, rute[39].getX(), rute[39].getY() - RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        rute[41] = new Rute(41, rute[40].getX(), rute[40].getY() - RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        // rekke under r�dt hus
        for(int i=42; i < 47; i++)
            rute[i] = new Rute(i, rute[i-1].getX() + RUTE_WIDTH, rute[i-1].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        // rekke til h�yre for r�dt hus
        rute[47] = new Rute(47, rute[46].getX() + RUTE_WIDTH, rute[46].getY() - RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        for(int i=48; i < 52; i++)
            rute[i] = new Rute(i, rute[i-1].getX(), rute[i-1].getY() - RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        // vei til gult m�l
        rute[52] = new Rute(52, rute[1].getX(), rute[1].getY() + RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        for(int i=53; i < 58; i++)
            rute[i] = new Rute(i, rute[i-1].getX(), rute[i-1].getY() + RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        // vei til gr�nt m�l
        rute[58] = new Rute(58, rute[14].getX() - RUTE_WIDTH, rute[14].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        for(int i=59; i < 64; i++)
            rute[i] = new Rute(i, rute[i-1].getX() - RUTE_WIDTH, rute[i-1].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        // vei til bl�tt m�l
        rute[64] = new Rute(64, rute[27].getX(), rute[27].getY() - RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        for(int i=65; i < 70; i++)
            rute[i] = new Rute(i, rute[i-1].getX(), rute[i-1].getY() - RUTE_HEIGHT, RUTE_WIDTH, RUTE_HEIGHT);
        // vei til r�dt m�l
        rute[70] = new Rute(70, rute[40].getX() + RUTE_WIDTH, rute[40].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        for(int i=71; i < 76; i++)
            rute[i] = new Rute(i, rute[i-1].getX() + RUTE_WIDTH, rute[i-1].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        // ruter i r�dt hus
        rute[89] = new Rute(89, HUSKANT, HUSKANT, RUTE_WIDTH, RUTE_HEIGHT);
        rute[88] = new Rute(88, HUSKANT, rute[89].getY() + RUTE_HEIGHT + MELLOM_RUTER_I_HUS, RUTE_WIDTH, RUTE_HEIGHT);
        rute[90] = new Rute(90, rute[88].getX() + RUTE_WIDTH + MELLOM_RUTER_I_HUS, rute[88].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        rute[91] = new Rute(91, rute[90].getX(), rute[89].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        // ruter i gult hus
        rute[76] = new Rute(76, rute[2].getX() + RUTE_WIDTH + HUSKANT - 1, HUSKANT - 1, RUTE_WIDTH, RUTE_HEIGHT);
        rute[77] = new Rute(77, rute[76].getX() + RUTE_WIDTH + MELLOM_RUTER_I_HUS - 1, HUSKANT - 1, RUTE_WIDTH, RUTE_HEIGHT);
        rute[78] = new Rute(78, rute[76].getX(), rute[76].getY() + RUTE_HEIGHT + MELLOM_RUTER_I_HUS, RUTE_WIDTH, RUTE_HEIGHT);
        rute[79] = new Rute(79, rute[77].getX(), rute[78].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        // ruter i gr�nt hus
        rute[80] = new Rute(80, rute[77].getX(), rute[15].getY() + RUTE_HEIGHT + HUSKANT, RUTE_WIDTH, RUTE_HEIGHT);
        rute[81] = new Rute(81, rute[80].getX(), rute[80].getY() + RUTE_HEIGHT + MELLOM_RUTER_I_HUS, RUTE_WIDTH, RUTE_HEIGHT);
        rute[82] = new Rute(82, rute[76].getX(), rute[80].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        rute[83] = new Rute(83, rute[82].getX(), rute[81].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        // ruter i bl�tt hus
        rute[84] = new Rute(84, rute[90].getX(), rute[83].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        rute[85] = new Rute(85, rute[88].getX(), rute[84].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        rute[86] = new Rute(86, rute[84].getX(), rute[82].getY(), RUTE_WIDTH, RUTE_HEIGHT);
        rute[87] = new Rute(87, rute[88].getX(), rute[86].getY(), RUTE_WIDTH, RUTE_HEIGHT);
    }
}